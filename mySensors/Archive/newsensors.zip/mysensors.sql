-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2015 at 10:01 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mysensors`
--

-- --------------------------------------------------------

--
-- Table structure for table `internaltypes`
--

CREATE TABLE IF NOT EXISTS `internaltypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `listenmessages`
--

CREATE TABLE IF NOT EXISTS `listenmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nodeId` int(11) DEFAULT NULL,
  `sensorId` int(11) DEFAULT NULL,
  `messageType` int(11) DEFAULT NULL,
  `ack` tinyint(4) DEFAULT NULL,
  `subType` int(11) DEFAULT NULL,
  `payload` varchar(25) DEFAULT NULL,
  `timeReceived` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE IF NOT EXISTS `locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `desc` varchar(45) DEFAULT NULL,
  `parentId` int(11) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`id`, `name`, `desc`, `parentId`, `status`) VALUES
(1, 'Phòng khách', '', 0, '1'),
(2, 'Phòng ngủ', '', 0, '1');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nodeId` int(11) DEFAULT NULL,
  `sensorId` int(11) DEFAULT NULL,
  `messageType` int(11) DEFAULT NULL,
  `ack` tinyint(4) DEFAULT NULL,
  `subType` int(11) DEFAULT NULL,
  `payload` varchar(25) DEFAULT NULL,
  `timeReceived` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4083 ;

-- --------------------------------------------------------

--
-- Table structure for table `messageshistory`
--

CREATE TABLE IF NOT EXISTS `messageshistory` (
  `idMessage` int(11) NOT NULL AUTO_INCREMENT,
  `nodeId` int(11) DEFAULT NULL,
  `sensorId` int(11) DEFAULT NULL,
  `messageType` int(11) DEFAULT NULL,
  `ack` tinyint(4) DEFAULT NULL,
  `subType` int(11) DEFAULT NULL,
  `payload` varchar(25) DEFAULT NULL,
  `timeReceived` datetime DEFAULT NULL,
  PRIMARY KEY (`idMessage`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `nodes`
--

CREATE TABLE IF NOT EXISTS `nodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `locationId` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `battery` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `version` varchar(45) DEFAULT NULL,
  `timePresented` datetime DEFAULT NULL,
  `lastConnected` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `location_idx` (`locationId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `nodes`
--

INSERT INTO `nodes` (`id`, `name`, `locationId`, `type`, `battery`, `status`, `version`, `timePresented`, `lastConnected`) VALUES
(2, '0hum-1temp-2light-3door', 1, 17, 100, 1, '', '0000-00-00 00:00:00', '2015-01-11 18:03:10'),
(5, '1motion-2light', 2, 17, 89, 1, '', '0000-00-00 00:00:00', '2015-01-11 07:21:59'),
(10, 'Relay & Button', 1, 18, NULL, 1, '', '0000-00-00 00:00:00', '2015-01-11 17:23:37');

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE IF NOT EXISTS `profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `startTime` datetime NOT NULL,
  `endTime` datetime NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf32 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `relaytypes`
--

CREATE TABLE IF NOT EXISTS `relaytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `comment` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `sensors`
--

CREATE TABLE IF NOT EXISTS `sensors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nodeId` int(11) NOT NULL,
  `sensorId` int(11) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `node_idx` (`nodeId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `sensors`
--

INSERT INTO `sensors` (`id`, `nodeId`, `sensorId`, `type`, `name`, `value`, `status`) VALUES
(1, 10, 1, 3, NULL, 0, NULL),
(2, 10, 2, 3, NULL, 0, NULL),
(3, 10, 3, 3, NULL, 0, NULL),
(4, 10, 4, 3, NULL, 0, NULL),
(5, 2, 0, 7, NULL, 42, NULL),
(6, 2, 1, 6, NULL, 30, NULL),
(7, 2, 2, 16, NULL, 47, NULL),
(8, 2, 3, 0, NULL, 1, NULL),
(9, 5, 1, 1, NULL, 1, NULL),
(10, 5, 2, 3, NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sensortypes`
--

CREATE TABLE IF NOT EXISTS `sensortypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Value',
  `type` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `viName` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

-- --------------------------------------------------------

--
-- Table structure for table `task-conditions`
--

CREATE TABLE IF NOT EXISTS `task-conditions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskId` int(11) NOT NULL,
  `sensorId` int(11) NOT NULL,
  `value` varchar(100) NOT NULL,
  `operator` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=140 ;

-- --------------------------------------------------------

--
-- Table structure for table `task-target`
--

CREATE TABLE IF NOT EXISTS `task-target` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskId` int(11) NOT NULL,
  `relayId` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  `operator` int(11) NOT NULL,
  `option` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=140 ;

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET latin1 NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=140 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `nodes`
--
ALTER TABLE `nodes`
  ADD CONSTRAINT `location` FOREIGN KEY (`locationId`) REFERENCES `locations` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sensors`
--
ALTER TABLE `sensors`
  ADD CONSTRAINT `node` FOREIGN KEY (`nodeId`) REFERENCES `nodes` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
